import React from 'react'

const Musicfeed = () => {
  return (
    <div className="musicfeed w-[300px] h-[80px] p-2 pl-2 pr-2 rounded-lg  flex items-center gap-2 justify-between">
        <div className="thumbnail w-[60px] h-[60px] overflow-hidden rounded-lg ">
            <img src="https://pbs.twimg.com/media/FyvbSxqWwAENxG-.jpg:large" alt="" />
        </div>
        <div className="text flex-col gap-3">
                <p className='musictitle text-white text-[15pt] font-semibold'>Naa Ready</p>
                <p className='author text-white text-[10pt]'>Anirudh Ravichander</p>
        </div>
        <div className="icons flex justify-center items-center gap-5 ">
                <i class='bx bx-heart text-[20pt] text-[rgb(196,196,196)] hover:text-white '></i>
                <i class='bx bx-cast text-[20pt] text-[rgb(196,196,196)]  hover:text-white' ></i>
        </div>

       
    </div>
  )
}

export default Musicfeed